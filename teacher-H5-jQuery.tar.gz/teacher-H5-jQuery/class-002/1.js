$(document).ready(function () {
    $("#myp").html("hello world");
})